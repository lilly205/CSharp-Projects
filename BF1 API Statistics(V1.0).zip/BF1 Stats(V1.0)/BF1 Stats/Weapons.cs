﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BF1_Stats.Resources
{
    public partial class Weapons : UserControl
    {
        public Weapons()
        {
            InitializeComponent();
        }
    }
}
